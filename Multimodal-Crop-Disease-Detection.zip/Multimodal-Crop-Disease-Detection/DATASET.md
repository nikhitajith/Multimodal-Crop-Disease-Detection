# Dataset instructions

Datasets are intentionally not included in this repository.

## Plant leaf images

The notebook uses `torchvision.datasets.ImageFolder`. Arrange the image dataset as:

```text
data/
└── plant_leaf_diseases/
    ├── class_1/
    │   ├── image_001.jpg
    │   └── image_002.jpg
    ├── class_2/
    │   └── image_003.jpg
    └── ...
```

Each class must have its own folder. The notebook infers class names from folder names.

## Weather data

Place the weather CSV in a local `data/weather/` directory and update the CSV path in the notebook. Keep the original data source, geographic coordinates, date range, units and any preprocessing decisions documented.

The current notebook does not correctly align weather rows with individual image samples. Merely placing a weather CSV in the folder does not make the multimodal experiment scientifically valid.

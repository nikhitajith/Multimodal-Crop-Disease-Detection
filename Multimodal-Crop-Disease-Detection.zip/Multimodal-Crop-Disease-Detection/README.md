# Multimodal Crop Disease Detection

An experimental deep-learning project exploring crop leaf disease classification with image features and auxiliary weather data.

## Project overview

The notebook explores:
- **Image classification:** ResNet50 transfer learning on a folder-based plant leaf image dataset.
- **Weather branch:** an LSTM experiment using tabular weather observations.
- **Multimodal fusion:** early feature fusion and weighted late fusion experiments.
- **Explainability:** Grad-CAM visualisation for the image classifier.
- **Evaluation:** classification reports, confusion matrices and model comparison plots.

The image dataset is expected to contain **39 class folders**. The notebook uses 224 × 224 image inputs.

## Repository contents

```text
Multimodal-Crop-Disease-Detection/
├── README.md
├── requirements.txt
├── .gitignore
├── DATASET.md
└── notebooks/
    └── final_codebook.ipynb
```

## Setup

Python 3.10 or 3.11 is recommended. Create and activate a virtual environment, then install the dependencies:

```bash
python -m venv .venv

# Windows
.venv\Scripts\activate

# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
```

For GPU training, install the PyTorch build appropriate for your CUDA version using the official PyTorch installation selector.

## Dataset setup

See [DATASET.md](DATASET.md) for the expected folder layout and data notes. The datasets are not included in this repository.

Update the dataset and weather CSV paths in the notebook to point to your local copies before running it. Do not commit private, licensed, or very large datasets.

## Running the notebook

```bash
jupyter notebook notebooks/final_codebook.ipynb
```

Run the notebook cells in order. Training time depends on dataset size and hardware; a CUDA-enabled GPU is recommended.

## Important experimental limitations

This repository contains an **experimental notebook**, not a fully validated multimodal prediction pipeline. In the current notebook:

1. Weather class labels are generated randomly for the weather-only experiment. They are not ground-truth crop disease labels and must not be interpreted as a meaningful supervised weather model.
2. Weather observations are not joined to individual leaf images. The notebook repeats a mean weather vector across image batches in the fusion experiments, so it does not establish sample-level image-weather correspondence.
3. The early-fusion weather feature branch is newly initialized in the notebook; it is not a trained weather encoder.
4. Some evaluation sections reuse prediction variables from earlier cells, so the reported metrics/plots may not correspond to the model named in their titles.
5. The notebook contains a local example image path (`crop.JPG`) for Grad-CAM; provide your own test image and update that path.

Consequently, **do not treat any accuracy value produced by this notebook as validated evidence that weather fusion improves disease prediction**. A defensible multimodal result requires correctly matched image, location, date and weather records; meaningful labels; leakage-safe splits; and a fresh evaluation.

## Next steps for a validated version

- Align weather observations to each image using documented location and capture-date metadata.
- Remove random-label training and use only valid labels.
- Train and validate the image and weather branches independently.
- Use consistent, leakage-safe train/validation/test splits.
- Recompute all metrics from the exact model being evaluated.
- Save model checkpoints, class mappings and experiment configuration.

## License

Add a license only after confirming that the source code and any included assets can legally be redistributed.
